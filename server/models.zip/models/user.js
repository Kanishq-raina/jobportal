// server/models/user.js
import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    resetToken: {
      type: String,
      
    },
    resetTokenExpiry: {
      type: Date,
      
    },
    
    username: {
      type: String,
      required: false,
      unique: true,
      trim: true,
      sparse:true,
    },

    password: {
      type: String,
      required: false,
    },

    role: {
      type: String,
      enum: ["admin", "student"],
      required: true,
    },

    name: {
      type: String,
      required: true,
      trim: true,
    },

    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },

    phone: {
      type: String,
      default: "",
    },

    avatar: {
      type: String, // URL or file path to profile photo
      default: "",
    },
  },
  {
    timestamps: true,
  }
);

export default mongoose.model("User", userSchema);
